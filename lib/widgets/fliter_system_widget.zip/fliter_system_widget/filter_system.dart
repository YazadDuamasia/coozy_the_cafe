/*
This code is a library file that exports all the widgets
and properties (props) of the Amazon-like filter functionality.
*/

export 'widgets/widgets.dart';
export 'props/props.dart';
